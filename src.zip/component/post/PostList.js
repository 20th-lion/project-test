import React from "react";
import PostItem from "./PostItem";

export default function PostList() {
  return (
    <div>
      <PostItem />
      <PostItem />
      <PostItem />
      <PostItem />
    </div>
  );
}
