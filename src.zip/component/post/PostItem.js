import React from "react";

export default function PostItem() {
  return <div>PostItem</div>;
}
