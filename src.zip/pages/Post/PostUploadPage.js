import React from "react";

export default function PostPage() {
  return <div>안녕하세요 수정된 페이지입니다</div>;
}
